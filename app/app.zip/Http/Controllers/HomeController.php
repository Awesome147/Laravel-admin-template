<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Subscription;
use Crypt;
use Auth;
use App\Models\Auth\User\User;
use ChargeBee_Plan;
use ChargeBee_Customer;
use ChargeBee_Subscription;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth', ['except' => ['index']]);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('welcome');
    }

    public function subscription(){
        $data = Subscription::all();
             return view('subscription',['data'=>$data]);
    }

    public function subscriptionPay($token){
       $id =  Crypt::decrypt($token);
       $SubscriptionData = Subscription::find($id);
       $userId = Auth::user()->id;
       $data['id'] = $id;
       $data['user'] = User::find($userId);
        return view('payment',$data);
    }


    public function payment(Request $req){
        require_once("./chargestripe/Config.php");
        require_once("./chargestripe/ErrorHandler.php");
        require_once("./chargestripe/Util.php");

        $subscription_id = $req->post('subscription_id');
        $plane_id = $req->post('subscription_id');
        $SubscriptionData = Subscription::find($subscription_id);
        $userId = $userId = Auth::user()->id;
        $userData = User::find($userId);
        $planId = !empty($SubscriptionData->planId) ? $SubscriptionData->planId : '' ;
         $customerId = !empty($userData->customer_id) ? $userData->customer_id : '' ;
        if ($_POST) {
          //  validateParameters($_POST);
            try {
                $result = ChargeBee_Subscription::create([
                        "planId" => $planId,
                        "autoCollection" => "off",
                         "billingAddress" => array(
                        "firstName" => $req->customer[first_name],
                        "lastName" => $req->customer[last_name],
                        "line1" => $req->addr,
                        "city" =>$req->city,
                        "state" => $req->state,
                        "zip" => $req->zip_code,
                        "country" => "US"
                        ),  
                        "customerId" => $customerId,  
                ]);
                $jsonResp = array();
                
                /*
                * Forwarding to success page after successful create subscription in ChargeBee.
                */
                $queryParameters = "name=" . urlencode($result->customer()->firstName) .
                            "&planId=" . urlencode($result->subscription()->planId);        
                $jsonResp["forward"] = "thankyou.html";
                echo json_encode($jsonResp, true);
                
            } catch(ChargeBee_PaymentException $e) {
                print_r($e);
                handleTempTokenErrors($e);
            } catch(ChargeBee_InvalidRequestException $e) {
                print_r($e);
                echo 'here';
                handleInvalidRequestErrors($e, "plan_id");
            } catch(Exception $e) {
                print_r($e);
                echo 'there';
                handleGeneralErrors($e);
            }
        }

    }

}
